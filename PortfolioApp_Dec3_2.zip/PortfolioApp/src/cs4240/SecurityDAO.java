package cs4240;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
 
public class SecurityDAO { //DAO = Data Access Object; this DAO handles interaction with Yahoo Finance AP
  
    private static final SecurityDAO stockDAO = new SecurityDAO();
    private static HashMap<String, Security> stocks = new HashMap<String, Security>();
    private static final long TWENTY_MIN = 1200000;
 
    private SecurityDAO() {}
 
    public static SecurityDAO getInstance() {
        return stockDAO;
    }
 
    public boolean isWeekend(String ts)
    {
    	String date[] = ts.split("/");
    	
        //int year = Integer.parseInt(ts.substring(0, 4));
        int year = Integer.parseInt(date[2]);
        
       // int month = Integer.parseInt(ts.substring(0, 2));
        int month = Integer.parseInt(date[0]);
       
        //int day = Integer.parseInt(ts.substring(6, 8));
        int day = Integer.parseInt(date[1]);
        
        Calendar cal = new GregorianCalendar(year, month - 1, day);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        return (Calendar.SUNDAY == dayOfWeek || Calendar.SATURDAY == dayOfWeek);
    }
   
    public Security getStockPrice(String symbol) {
        Security stock;
        long currentTime = (new Date()).getTime();
        // Check last updated and only pull stock on average every 20 minutes
        if (stocks.containsKey(symbol)) {
            stock = stocks.get(symbol);
            if(currentTime - stock.getLastUpdated() > TWENTY_MIN) {
                stock = refreshStockInfo(symbol, currentTime);
            }
        } else {
            stock = refreshStockInfo(symbol, currentTime);
        }
        return stock;
    }
    
    
 
    //This is synched so we only do one request at a time
    //If yahoo doesn't return stock info we will try to return it from the map in memory
    private synchronized Security refreshStockInfo(String symbol, long time) {
        try {
            URL yahoofin = new URL("http://finance.yahoo.com/d/quotes.csv?s=" + symbol + "&f=sl&e=.csv");
        	URLConnection yc = yahoofin.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            String inputLine;
            Security stockInfo = new Stock();
            while ((inputLine = in.readLine()) != null) {
                String[] yahooStockInfo = inputLine.split(",");
                stockInfo.setTicker(yahooStockInfo[0].replaceAll("\"", ""));
                stockInfo.setPrice(Float.valueOf(yahooStockInfo[1]));
                stockInfo.setDate(yahooStockInfo[2].replaceAll("\"", ""));
                String date[] = stockInfo.getDate().split("/");
                System.out.println(stockInfo.getDate());
                String newM=date[0], newD=date[1];
                if (date[0].length()==1){
                	newM = "0"+date[0];
                	stockInfo.setDate(newM+"/"+newD+"/"+date[2]);
                }
                if (date[1].length()==1){
                	newD = "0"+date[1];
                	stockInfo.setDate(newM+"/"+newD+"/"+date[2]);
                }
               
               System.out.println(stockInfo.getDate());
               System.out.println("is weekend?" + isWeekend("11/30/2013"));
               break;
            }
            in.close();
            
            //update 1-month price
            String m1 = stockInfo.getDate();
            System.out.println(stockInfo.getDate());
            
            String ss1 = m1.substring(0, 2);
            System.out.println("Month "+ ss1);
            
            String ss2 = m1.substring(3, 5);
            System.out.println("Day "+ss2);
            
            String ss3 = m1.substring(6, 10);
            
          //System.out.println(yahoofin2);
            System.out.println(ss1+"/"+ss2+"/"+ss3);
           // System.out.println("Is weekend for Nov 3 "+ isWeekend(ss1+"/"+ss2+"/"+ss3));
            
            int mnum1 = Integer.parseInt(ss1) - 2; //current month - 2
            
            int newM = mnum1 +1;
            
            if (newM<10){
            	ss1 = "0" + newM;
            }
            else {
            	ss1 = ""+newM;
            }
            int dnum1 = Integer.parseInt(ss2);
            int ynum1 = Integer.parseInt(ss3);

            URL yahoofin2;
            
            if (isWeekend(ss1+"/"+ss2+"/"+ss3)){
            	System.out.println("evaluated");
            	int dnumNew = dnum1-2;
            	yahoofin2 = new URL("http://ichart.yahoo.com/table.csv?s=" + symbol + 
                		"&a=" + mnum1 + "&b=" + dnumNew + "&c=" + ynum1 + "&d=" + mnum1 + 
                		"&e=" + dnumNew + "&f=" + ynum1 + "&g=w&ignore=.csv");            	
            }
            else{
            	yahoofin2 = new URL("http://ichart.yahoo.com/table.csv?s=" + symbol + 
                		"&a=" + mnum1 + "&b=" + dnum1 + "&c=" + ynum1 + "&d=" + mnum1 + 
                		"&e=" + dnum1 + "&f=" + ynum1 + "&g=w&ignore=.csv");
            }
            
            System.out.println(yahoofin2);
           
            URLConnection yc2 = yahoofin2.openConnection();
            BufferedReader in2 = new BufferedReader(new InputStreamReader(yc2.getInputStream()));
            String inputLine2;
            int checkline = 0;
            
            while (((inputLine2 = in2.readLine()) != null)) {
                String[] yahooStockInfo = inputLine2.split(",");
                if (checkline==1) {stockInfo.setMonthPrice(Float.valueOf(yahooStockInfo[4]));}
                checkline++;
 
            }
            in2.close();
            
            
            //update 6 month price
            System.out.println("1 month ago "+(ss1+"/"+ss2+"/"+ss3));
            System.out.println("6 month");
            int mnum2 = Integer.parseInt(ss1) - 6; //current month - 7
            
            int newM2 = mnum2 +1;
            
            if (newM2<10){
            	ss1 = "0" + newM2;
            }
            else {
            	ss1 = ""+newM2;
            }
           
            URL yahoofin3;
            
            System.out.println("6 months ago "+(ss1+"/"+ss2+"/"+ss3));
            System.out.println(mnum2+ " " +newM2);
            
            if (isWeekend(ss1+"/"+ss2+"/"+ss3)){
            	System.out.println("evaluated");
            	int dnumNew = dnum1-2;
            	yahoofin3 = new URL("http://ichart.yahoo.com/table.csv?s=" + symbol + 
                		"&a=" + mnum2 + "&b=" + dnumNew + "&c=" + ynum1 + "&d=" + mnum2 + 
                		"&e=" + dnumNew + "&f=" + ynum1 + "&g=w&ignore=.csv");            	
            }
            else{
            	yahoofin3 = new URL("http://ichart.yahoo.com/table.csv?s=" + symbol + 
                		"&a=" + mnum2 + "&b=" + dnum1 + "&c=" + ynum1 + "&d=" + mnum2 + 
                		"&e=" + dnum1 + "&f=" + ynum1 + "&g=w&ignore=.csv");
            }
            
            URLConnection yc3 = yahoofin3.openConnection();
            BufferedReader in3 = new BufferedReader(new InputStreamReader(yc3.getInputStream()));
            String inputLine3;
            int checkline2 = 0;
            while ((inputLine3 = in3.readLine()) != null) {
            	System.out.println(inputLine3);
            	System.out.println("6 while");
                String[] yahooStockInfo = inputLine3.split(",");
                if (checkline2==1) {stockInfo.setHalfYPrice(Float.valueOf(yahooStockInfo[4]));}
                checkline2++;
               System.out.println(stockInfo.getHalfYPrice());
            }
            in3.close();
            
            //update year price
            int ynum2 = ynum1 - 1;
            ss3 = ""+ ynum2 ;
            
            int mnum3 = mnum1 + 1; 
            int newM3 = mnum3 +1;
            
            if (newM3<10){
            	ss1 = "0" + newM3;
            }
            else {
            	ss1 = ""+newM3;
            }
            
            URL yahoofin4;
            
            if (isWeekend(ss1+"/"+ss2+"/"+ss3)){
            	System.out.println("evaluated");
            	int dnumNew = dnum1-2;
            	yahoofin4 = new URL("http://ichart.yahoo.com/table.csv?s=" + symbol + 
                		"&a=" + mnum3 + "&b=" + dnumNew + "&c=" + ynum2 + "&d=" + mnum3 + 
                		"&e=" + dnumNew + "&f=" + ynum2 + "&g=w&ignore=.csv");            	
            }
            else{
            	yahoofin4 = new URL("http://ichart.yahoo.com/table.csv?s=" + symbol + 
                		"&a=" + mnum3 + "&b=" + dnum1 + "&c=" + ynum2 + "&d=" + mnum3 + 
                		"&e=" + dnum1 + "&f=" + ynum2 + "&g=w&ignore=.csv");
            }
            System.out.println("1 year ago "+ss1+"/"+ss2+"/"+ss3);
            
            URLConnection yc4 = yahoofin4.openConnection();
            BufferedReader in4 = new BufferedReader(new InputStreamReader(yc4.getInputStream()));
            String inputLine4;
            int checkline3 = 0;
            while ((inputLine4 = in4.readLine()) != null) {
            	
                String[] yahooStockInfo = inputLine4.split(",");
                if (checkline3==1) {stockInfo.setYPrice(Float.valueOf(yahooStockInfo[4]));}
                checkline3++;
               
            }
            in4.close();
            stocks.put(symbol, stockInfo);
        } catch (Exception ex) {
        }
        return stocks.get(symbol);
     }
    
    }
