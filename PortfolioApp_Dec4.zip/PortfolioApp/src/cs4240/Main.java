package cs4240;

import java.io.IOException;

import cs4240.gui.Login;
import cs4240.portfolio.Portfolio;
import cs4240.security.Index;
import cs4240.security.Security;
import cs4240.security.Stock;

public class Main {

	/**
	 * @param args
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException, InstantiationException, IllegalAccessException {
		// TODO Auto-generated method stub
		User mainUser = new User("Kate", "password");
		Portfolio finPort = new Portfolio(mainUser.getUsername(),"Finance Portfolio");
		Portfolio port2 = new Portfolio(mainUser.getUsername(),"Sample Portfolio");
		
		Security goog = new Stock("GOOG");
		Security sp = new Index("gspc");
		Security att = new Stock("T");

		finPort.addSecurity(goog);
		finPort.addSecurity(att);
		finPort.addSecurity(sp);
		port2.addSecurity(goog);
		
		mainUser.getPortfolioList().add(finPort);
		mainUser.getPortfolioList().add(port2);

		Login loginScreen = new Login(mainUser);
	}

}
