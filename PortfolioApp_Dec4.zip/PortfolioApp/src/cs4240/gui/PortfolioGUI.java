package cs4240.gui;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JSpinner;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;

import cs4240.User;
import cs4240.portfolio.Portfolio;

import java.awt.List;
import javax.swing.JLabel;
import java.awt.Panel;
import javax.swing.BoxLayout;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Color;
import java.net.MalformedURLException;
import java.util.ArrayList;

public class PortfolioGUI extends JFrame {
	ArrayList<Portfolio> portfolioList;
	User mainUser;
	final List list = new List();
	
	
	public PortfolioGUI(final User mainUser, final ArrayList<Portfolio> portfolioList) {
		// Set the window settings
		setTitle("Portfolios");
		setSize(345, 465);
		setVisible(true);
		
		
		// declare portfolioList variable to use in outside update method
		this.portfolioList = portfolioList;
		this.mainUser = mainUser;
		
		// Set up window layouts
		getContentPane().setLayout(null);
		final Panel panel = new Panel();
		panel.setBackground(SystemColor.desktop);
		panel.setBounds(10, 227, 309, 129);
		getContentPane().add(panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		
		// Fill in the list of portfolios with outside method and add to the panel
		updateList();
		panel.add(list);
		
		// View the specific compostition for a portfolio
		// Close portfolio window and open Composition window
		// Note: portfolio must be selected to move forward
		JButton btnNewButton = new JButton("View Portfolio Composition");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String portfolioName = list.getSelectedItem();				
				try {
					CompositionGUI composition = new CompositionGUI(mainUser, portfolioName, list.getSelectedIndex(), portfolioList.get(list.getSelectedIndex()).getSecurityList());
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				setVisible(false);
			}
		});
		btnNewButton.setBounds(10, 393, 309, 23);
		getContentPane().add(btnNewButton);
	
		// Set instruction label for user
		JLabel lblChooseDesirePortfolio = new JLabel("Choose Desired Portfolio:");
		lblChooseDesirePortfolio.setBounds(10, 207, 309, 14);
		getContentPane().add(lblChooseDesirePortfolio);
		
		// Label for above portfolio list
		JLabel lblPortfolios = new JLabel("Portfolios");
		lblPortfolios.setForeground(new Color(255, 0, 0));
		lblPortfolios.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPortfolios.setHorizontalAlignment(SwingConstants.CENTER);
		lblPortfolios.setBounds(10, 0, 309, 25);
		getContentPane().add(lblPortfolios);
		
		// Add a Portfolio to the list by specifying the name
		// Open "Add Portfolio" GUI
		// open the fresh Portfolio GUI after
		JButton btnAddPortfolio = new JButton("Add Portfolio");
		btnAddPortfolio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddPortfolio addPort  = new AddPortfolio(mainUser);
				panel.remove(list);
				updateList();
				panel.add(list);
				panel.repaint();
			}
		});
		btnAddPortfolio.setBounds(10, 362, 157, 23);
		getContentPane().add(btnAddPortfolio);
		
		// Create a panel to add contents
		Panel panel_1 = new Panel();
		panel_1.setBackground(SystemColor.desktop);
		panel_1.setBounds(10, 31, 309, 170);
		getContentPane().add(panel_1);
		
		// Remove the selected portfolio from the list
		JButton btnRemovePortfolio = new JButton("Remove Portfolio");
		btnRemovePortfolio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				panel.remove(list);
				mainUser.getPortfolioList().remove(list.getSelectedIndex());
				updateList();
				panel.add(list);
				panel.repaint();
			}
		});
		btnRemovePortfolio.setBounds(171, 362, 148, 23);
		getContentPane().add(btnRemovePortfolio);
		
	}
	
	// update the list of portfolios for the user
	public void updateList(){
		list.clear();
		for (Portfolio port: mainUser.getPortfolioList())
		{
			list.add(port.getName());
		}
		
	}
}
