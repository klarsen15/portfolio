package cs4240.gui;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JButton;

import cs4240.User;
import cs4240.portfolio.Portfolio;
import cs4240.portfolio.PortfolioCalculator;
import cs4240.security.Security;
import cs4240.security.data.SecurityDAO;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import java.awt.List;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Desktop;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.Font;
import java.awt.Color;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.AbstractListModel;
import javax.swing.border.BevelBorder;
import javax.swing.border.MatteBorder;
import javax.swing.JTable;
import javax.swing.JSplitPane;
import javax.swing.JTextPane;
import javax.swing.JInternalFrame;

public class Performance extends JFrame {
	// Following fields needing in outside method calls
	private final JButton btnPortfolio = new JButton("View Portfolios");
	final List list = new List();
	final JPanel panel_performance = new JPanel();
	List listData = new List();
	List listPerf = new List();
	
	
	public Performance(final User mainUser, final String portfolioName, final int portIndex, final ArrayList<Security> securityList) {
		// Set up window
		setTitle("Performance");
		setSize(548, 590);
		setVisible(true);
		
		// Create PortfolioCalculator to later use to retrieve total Portfolio performance
		final PortfolioCalculator portCalc = new PortfolioCalculator(mainUser.getPortfolioList().get(portIndex));
		
		/*
		 * View Portfolios Button
		 * Open Portfolio GUI
		 * Close Performance GUI
		 */
		btnPortfolio.setBounds(32, 518, 228, 23);
		btnPortfolio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PortfolioGUI portfolio = new PortfolioGUI(mainUser, mainUser.getPortfolioList());
				setVisible(false);
			}
		});
		getContentPane().setLayout(null);
		getContentPane().add(btnPortfolio);
		
		/*
		 * View Composition Button
		 * Open Composition GUI
		 * Close Performance GUI
		 */
		JButton btnReturnToComposition = new JButton("View Composition");
		btnReturnToComposition.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					CompositionGUI comp = new CompositionGUI(mainUser, portfolioName, portIndex, securityList);
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				setVisible(false);
			}
		});
		btnReturnToComposition.setBounds(32, 492, 228, 23);
		getContentPane().add(btnReturnToComposition);

		/*
		 * Populate the GUI list to show the securities
		 * Display the ticker for each Security
		 */
		for (Security sec: securityList)
		{
			list.add(sec.getTicker());
		}
		
		/*
		 * Create label for the security list above
		 */
		JLabel lblPortfolioComposition = new JLabel("Portfolio Composition");
		lblPortfolioComposition.setBounds(10, 335, 190, 14);
		getContentPane().add(lblPortfolioComposition);
		
		/*
		 * Label for the data type options (Chart, Data, Total Performance)
		 */
		final JLabel lblPortfolioPerformance = new JLabel("Select to View Performance");
		lblPortfolioPerformance.setForeground(new Color(255, 0, 0));
		lblPortfolioPerformance.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPortfolioPerformance.setHorizontalAlignment(SwingConstants.CENTER);
		lblPortfolioPerformance.setBounds(10, 11, 512, 14);
		getContentPane().add(lblPortfolioPerformance);
		
		/*
		 * Set up the panel performance
		 * The chart / data / total performance will be added to this panel
		 */
		panel_performance.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel_performance.setBackground(SystemColor.desktop);
		panel_performance.setBounds(10, 36, 512, 288);
		getContentPane().add(panel_performance);
		panel_performance.setLayout(null);
		
		/*
		 * Create lblDataOutput to later populate with selected data type
		 * Will be used for following functions:
		 * setIcon for Chart
		 * addComponent for Data List
		 * addComponent for Total Performance List
		 */
		final JLabel lblDataOutput = new JLabel(" ");
		lblDataOutput.setBounds(0, 0, 512, 288);
		lblDataOutput.setIcon(new ImageIcon("C:\\Users\\Student\\Documents\\GitHub\\portfolio\\yahoo finance new logo.png"));
		panel_performance.add(lblDataOutput);
		
		/*
		 * Create a split panel for Security list : Data type
		 * Left: Security composition
		 * Right: Chart, Data, Total Performance
		 */
		JSplitPane splitPane = new JSplitPane();
		splitPane.setBounds(10, 349, 512, 135);
		getContentPane().add(splitPane);
		splitPane.setLeftComponent(list);
		
		/*
		 * List that will hold the different dataTypes offered
		 * Set the data types and allow for single selection
		 */
		final JList dataType = new JList();
		splitPane.setRightComponent(dataType);
		dataType.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null));
		dataType.setBackground(SystemColor.desktop);
		dataType.setForeground(new Color(0, 0, 0));
		dataType.setModel(new AbstractListModel() {
			String[] values = new String[] {"Chart", "Data", "Total Portfolio Performance"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		dataType.setSelectedIndex(0);
		dataType.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		
		/*
		 * Main Functionality of this GUI
		 * Updates the lblDataOutput
		 * Dependent upon Security chosen and Data Type chosen
		 * Evaluates different output based upon Data Type Chose
		 */
		JButton btnViewPerformance = new JButton("Update Performance");
		btnViewPerformance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String tickerSend = list.getSelectedItem();	
				int tickerIndex = list.getSelectedIndex();
				int inputType = dataType.getSelectedIndex();
				
				// Option 1: Create a Chart
				if (inputType == 0){
					lblDataOutput.remove(listData);
					lblDataOutput.remove(listPerf);
					try {
						URL chartURL = securityList.get(tickerIndex).formChartURL(tickerSend);
						lblDataOutput.setIcon(new ImageIcon(ImageIO.read(chartURL)));
								//new URL("http://chart.finance.yahoo.com/w?s="+tickerSend))));
					} catch (MalformedURLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				// Option 2: Display raw data
				else if (inputType == 1){
					lblDataOutput.setIcon(null);
					lblDataOutput.remove(listPerf);
					addDataList(securityList, tickerIndex);
					lblDataOutput.add(listData);

				}
				
				// Option 3: Display total performance for the portfolio
				else if (inputType == 2){
					lblDataOutput.setIcon(null);
					lblDataOutput.remove(listData);
					addPerfList(portCalc, securityList);
					lblDataOutput.add(listPerf);
				}
				
				// Set hte window title and main label on the screen for the ticker and data type chosen
				setTitle("Performance for " + tickerSend);
				lblPortfolioPerformance.setText("Performance " + (String)dataType.getSelectedValue()+" for "+tickerSend);
			}
		});
		btnViewPerformance.setBounds(315, 491, 207, 50);
		getContentPane().add(btnViewPerformance);
		
	}
	
	/*
	 * Used in Option 2: Display raw data
	 * Add date, current price, previous month price, hy price, y price to the displayed list
	 */
	public void addDataList(ArrayList<Security> securityList, int tickerIndex){
		listData.setBounds(0, 0, 512, 288);
		
		// need to clear out list first
		listData.removeAll();
		
		// retrieve values
		String curDate = "Current Date: " + securityList.get(tickerIndex).getDate();
		String mPrice = "Previous Month Price: "+ securityList.get(tickerIndex).getMonthPrice();
		String hyPrice = "Previous Half Year Price: "+ securityList.get(tickerIndex).getHalfYPrice();
		String yPrice = "Previous Year Price: "+ securityList.get(tickerIndex).getYPrice();
		String curPrice = "Current Price: " + securityList.get(tickerIndex).getPrice();

		// set values
		listData.add(securityList.get(tickerIndex).getTicker());
		listData.add("");
		listData.add(curDate);
		listData.add("");
		listData.add(curPrice);
		listData.add("");
		listData.add(mPrice);
		listData.add(hyPrice);
		listData.add(yPrice);
	}
	
	/*
	 * Used in Option 3: Display total portfolio performance
	 */
	public void addPerfList(PortfolioCalculator portCalc, ArrayList<Security> securityList){
		listPerf.setBounds(0, 0, 512, 288);
		
		// clear out list
		listPerf.removeAll();
		
		// retrieve values using portfolioCalculator
		// values will be the same for any ticker selected as it for TOTAL performance
		String mRet = (portCalc.getMonthReturn()*100 + "").substring(0, 5);
		String hyRet= (portCalc.getHalfYReturn()*100 + "").substring(0, 5);
		String yRet = (portCalc.getYReturn()*100 + "").substring(0, 5);
		
		String monthReturn = "Month Return:  " + mRet+"%";
		String hyReturn = "Half Year Return:  " + hyRet+"%";
		String yReturn = "Year Return:  " + yRet+"%";
				
		// add values to the list
		listPerf.add("Total Portfolio Return:");
		listPerf.add("");
		listPerf.add(monthReturn);
		listPerf.add(hyReturn);
		listPerf.add(yReturn);
		
		panel_performance.add(listData);
	}
	
}
