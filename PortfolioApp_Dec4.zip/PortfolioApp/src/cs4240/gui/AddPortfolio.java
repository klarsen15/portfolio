package cs4240.gui;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;

import cs4240.User;
import cs4240.portfolio.Portfolio;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JSplitPane;

public class AddPortfolio extends JFrame implements Runnable {
	private JTextField txtPortName;
	boolean complete=false;
	private User mainUser;
	
	public AddPortfolio(final User mainUser) {
		this.mainUser = mainUser;
		setTitle("Add Portfolio");
		setSize(312, 217);
		getContentPane().setLayout(null);
		setVisible(true);
		
		JLabel lblAddAPortfolio = new JLabel("Add a Portfolio");
		lblAddAPortfolio.setBounds(0, 11, 278, 17);
		lblAddAPortfolio.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblAddAPortfolio.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(lblAddAPortfolio);
		
		JButton btnAddPortfolio = new JButton("Add Portfolio");
		btnAddPortfolio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				mainUser.getPortfolioList().add(new Portfolio(mainUser.getUsername(), txtPortName.getText()));
				complete = true;
				setVisible(false);
				PortfolioGUI portGUI = new PortfolioGUI(mainUser, mainUser.getPortfolioList());
			}
		});
		btnAddPortfolio.setBounds(83, 135, 133, 23);
		getContentPane().add(btnAddPortfolio);
		
		JSplitPane splitPane = new JSplitPane();
		splitPane.setBounds(10, 59, 278, 43);
		getContentPane().add(splitPane);
		
		JLabel lblEnterPortfolioName = new JLabel("Enter Portfolio Name");
		splitPane.setLeftComponent(lblEnterPortfolioName);
		
		txtPortName = new JTextField();
		splitPane.setRightComponent(txtPortName);
		txtPortName.setToolTipText("Enter Portfolio Name\r\n");
		txtPortName.setColumns(10);
	}
	
	public String getPortName(){
		return txtPortName.getText();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		JButton btnAddPortfolio = new JButton("Add Portfolio");
		btnAddPortfolio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				mainUser.getPortfolioList().add(new Portfolio(mainUser.getUsername(), txtPortName.getText()));
				complete = true;
				
				setVisible(false);
				//PortfolioGUI portGUI = new PortfolioGUI(mainUser, mainUser.getPortfolioList());
			}
		});
		btnAddPortfolio.setBounds(83, 135, 133, 23);
		getContentPane().add(btnAddPortfolio);
	}
}
