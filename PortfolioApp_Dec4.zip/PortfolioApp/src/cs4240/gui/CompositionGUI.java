package cs4240.gui;

import javax.imageio.ImageIO;

import javax.swing.JFrame;
import javax.swing.JButton;

import cs4240.User;
import cs4240.portfolio.Portfolio;
import cs4240.security.Security;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import javax.swing.JList;
import javax.swing.JRadioButton;
import java.awt.List;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Desktop;
import java.awt.Image;
import java.awt.SystemColor;
import java.awt.Font;
import java.awt.Color;
import java.awt.Window;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.border.BevelBorder;
import javax.swing.JTabbedPane;
import java.awt.Canvas;
import java.awt.Button;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.JProgressBar;

public class CompositionGUI extends JFrame {
	private JTable table;
	User mainUser;
	int portIndex;
	
	// Instantiate the ticker and weight lists to display
	final List list = new List();
	final List list_weights = new List();
	final JLabel labelPic= new JLabel();
	
	
	
	public CompositionGUI(final User mainUser, final String portfolioName, final int portIndex, final ArrayList<Security> securityList) throws MalformedURLException{
		this.mainUser = mainUser;
		this.portIndex = portIndex;
		boolean needRepaint;
		
		
		// Set up window settings
		setTitle("Composition for " + portfolioName);
		setSize(345, 465);
		getContentPane().setLayout(null);
		
		// balance the weights for the current Portfolio's Security List
		mainUser.getPortfolioList().get(portIndex).balanceWeight();
		 
		// Revert to previous Portfolio Screen
		JButton btnViewPortfolios = new JButton("View Portfolios");
		btnViewPortfolios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PortfolioGUI portfolio = new PortfolioGUI(mainUser, mainUser.getPortfolioList());
				setVisible(false);
			}
		});
		btnViewPortfolios.setBounds(10, 395, 309, 23);
		getContentPane().add(btnViewPortfolios);
		
		// Create new panel for window to later fill
		final JPanel panel = new JPanel();
		panel.setBounds(10, 195, 309, 134);
		getContentPane().add(panel);
		panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
		updateList();
		panel.add(list);
		panel.add(list_weights);
		panel.repaint();
		
		// Set the format for the window
		JLabel lblPortfolioComposition = new JLabel("Composition for "+portfolioName);
		lblPortfolioComposition.setForeground(new Color(255, 0, 0));
		lblPortfolioComposition.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPortfolioComposition.setHorizontalAlignment(SwingConstants.CENTER);
		lblPortfolioComposition.setBounds(10, 0, 309, 35);
		getContentPane().add(lblPortfolioComposition);
		final JPanel panel_details = new JPanel();
		panel_details.setBackground(SystemColor.desktop);
		panel_details.setBounds(10, 33, 309, 134);
		getContentPane().add(panel_details);
		
		// Make the chart and display it as the labelPic icon
		//URL chartURL = makeChart();
		//labelPic.setIcon( new ImageIcon(chartURL));
		//labelPic.setIcon(new ImageIcon(new URL(urlTxt)));
		makeChart();
		panel_details.add(labelPic);
		panel_details.repaint();
		
		// Add a security and re-open the gui
		JButton btnAddSecurity = new JButton("Add Security");
		btnAddSecurity.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AddSecurity addSec = new AddSecurity(mainUser, portIndex);
			}
		});
		btnAddSecurity.setBounds(10, 170, 110, 23);
		getContentPane().add(btnAddSecurity);
		
		// Edit a security, not implemented fully
		JButton btnEdit = new JButton("Edit");
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnEdit.setBounds(125, 170, 77, 23);
		getContentPane().add(btnEdit);
		setVisible(true);
		
		// Open Performance GUI, close Composition GUI
		JButton btnViewPerformance = new JButton("View Performance");
		btnViewPerformance.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Performance performance = new Performance(mainUser, portfolioName, portIndex, securityList);
				setVisible(false);
			}
		});
		btnViewPerformance.setBounds(10, 361, 309, 23);
		getContentPane().add(btnViewPerformance);
		
		// Delete Security from the Composition List
		JButton btnDeleteSecurity = new JButton("Delete Security");
		btnDeleteSecurity.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				mainUser.getPortfolioList().get(portIndex).getSecurityList().remove(list.getSelectedIndex());
				mainUser.getPortfolioList().get(portIndex).balanceWeight();
				panel.remove(list);
				panel.remove(list_weights);
				updateList();
				panel.add(list);
				panel.add(list_weights);
				panel.repaint();
				
				
				 // Old chart code
				 
				panel_details.remove(labelPic);
				try {
					makeChart();
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				panel_details.add(labelPic);
				panel_details.repaint();
				
				/*
				panel_details.remove(labelPic);
				URL chartURL = null;
				try {
					chartURL = makeChart();
					labelPic.setIcon( new ImageIcon(chartURL));
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				//labelPic.setIcon( new ImageIcon(chartURL));
				//labelPic.setIcon(new ImageIcon(new URL(urlTxt)));
				//makeChart();
				panel_details.add(labelPic);
				panel_details.repaint();
				*/
			}
		});
		btnDeleteSecurity.setBounds(203, 170, 116, 23);
		getContentPane().add(btnDeleteSecurity);

		
	}
	
	public void updateList(){
		list.clear();
		list_weights.clear();
		for (Security sec: mainUser.getPortfolioList().get(portIndex).getSecurityList())
		{
			list.add(sec.getTicker());
			String wt = "Weight: "+sec.getWeight();
			list_weights.add(wt);
		}
		
	}
	
	public void makeChart() throws MalformedURLException{
	
	//public URL makeChart() throws MalformedURLException{
		//labelPic.setIcon(null);
		String[] weights = null;
		String[] tickers = null;
		ArrayList<Security> secList = mainUser.getPortfolioList().get(portIndex).getSecurityList();
		String weightTxt = "00", tckrTxt = "";
		String weight = "00";
		
		for (int i = 0; i < secList.size(); i ++){
			weight = (Math.floor((secList.get(i).getWeight()*100)))+"";
			String weightCut = (weight).substring(0, 2);
			String ticker = secList.get(i).getTicker();
			
			if (i == 0 || (secList.size()==1)){
				weightTxt += weightCut;
				tckrTxt += ticker;
			}
			/*
			else if (i != (secList.size())-1){
				weightTxt += ","+weightCut + ",";
				tckrTxt += "|"+ticker;
			}
			*/
			else{
				weightTxt += ","+weightCut;
				tckrTxt += "|"+ticker;
			}
		}
		
		String urlTxt = "https://chart.googleapis.com/chart?chs=250x100&chd=t:" + weightTxt + "&cht=p3&chl=" + tckrTxt;
		URL chartURL = new URL(urlTxt);
		
		//return chartURL;
		
		labelPic.setIcon( new ImageIcon(chartURL));
		//labelPic.setIcon(new ImageIcon(new URL(urlTxt)));
	}
}
