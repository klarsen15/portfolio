package cs4240.gui;

import javax.swing.JFrame;

import cs4240.User;
import cs4240.security.Index;
import cs4240.security.Security;
import cs4240.security.Stock;

import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JSplitPane;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.MalformedURLException;

public class AddSecurity extends JFrame {
	private JTextField txtSecurityname;
	public AddSecurity(final User mainUser, final int portIndex) {
		final String portName = mainUser.getPortfolioList().get(portIndex).getName();
		
		
		setTitle("Add Security");
		setSize(312, 400);
		getContentPane().setLayout(null);
		
		JLabel lblAddSec = new JLabel("Add a Security");
		lblAddSec.setBounds(0, 11, 296, 14);
		lblAddSec.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(lblAddSec);
		
		
		
		JSplitPane splitPane_2 = new JSplitPane();
		splitPane_2.setOrientation(JSplitPane.VERTICAL_SPLIT);
		splitPane_2.setBounds(20, 54, 252, 214);
		getContentPane().add(splitPane_2);
		
		JSplitPane splitPane = new JSplitPane();
		splitPane_2.setLeftComponent(splitPane);
		
		JLabel lblNewLabel = new JLabel("Choose Stock or Index");
		splitPane.setLeftComponent(lblNewLabel);
		
		final JList listStockInd = new JList();
		listStockInd.setModel(new AbstractListModel() {
			String[] values = new String[] {"Stock", "Index"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		splitPane.setRightComponent(listStockInd);
		
		JSplitPane splitPane_1 = new JSplitPane();
		splitPane_2.setRightComponent(splitPane_1);
		
		JLabel lblSecurityName = new JLabel("Security Ticker");
		splitPane_1.setLeftComponent(lblSecurityName);
		
		txtSecurityname = new JTextField();
		splitPane_1.setRightComponent(txtSecurityname);
		txtSecurityname.setColumns(10);
		setVisible(true);
		
		JButton btnAddSecurityTo = new JButton("Add Security to Portfolio");
		btnAddSecurityTo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String ticker = txtSecurityname.getText();
				//Stock
				if (listStockInd.getSelectedIndex()==0){
					try {
						Security newStock = new Stock(ticker);
						mainUser.getPortfolioList().get(portIndex).addSecurity(newStock);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InstantiationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				//Index
				else if (listStockInd.getSelectedIndex() == 1){
					try {
						Security newIndex = new Index(ticker);
						mainUser.getPortfolioList().get(portIndex).addSecurity(newIndex);
					} catch (InstantiationException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				mainUser.getPortfolioList().get(portIndex).balanceWeight();
				try {
					CompositionGUI compGUI = new CompositionGUI (mainUser, portName, portIndex, mainUser.getPortfolioList().get(portIndex).getSecurityList());
				
				} catch (MalformedURLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				setVisible(false);
			}
		});
		btnAddSecurityTo.setBounds(66, 310, 159, 23);
		getContentPane().add(btnAddSecurityTo);
	}
}
