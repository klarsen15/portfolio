package cs4240;

import java.net.MalformedURLException;
import java.net.URL;

public abstract class Security {
    String ticker;
    float price;
    String currentdate;
    float month_price; //price 1 month ago
    float halfy_price; //price 6 months ago
    float y_price; //price 1 year ago
    long lastUpdated;
    float monthreturn;
	float halfyreturn;
	float yreturn;
	float weight;
	URL chartURL;
    
	public Security(){};
    public Security(String ticker, float price, String currentdate, float month_price, 
        		float halfy_price, float y_price, long lastUpdated) throws MalformedURLException {
    	this.ticker = ticker;
    	this.price = price;
    	this.currentdate = currentdate;
    	this.month_price = month_price;
    	this.halfy_price = halfy_price;
    	this.y_price = y_price;
    	this.lastUpdated = lastUpdated;
    	this.chartURL = formChartURL(ticker);
    		   	
    }
    public long getLastUpdated(){
    	return lastUpdated;
    }
 
    public String getDate(){
        return currentdate;
    }
    public void setDate(String currentdate){
        this.currentdate = currentdate;
    }
    
    public String getTicker(){
        return ticker;
    }
    public void setTicker(String ticker) {
        this.ticker = ticker;
    }
    public float getMonthPrice() {
        return month_price;
    }
    public void setMonthPrice(float month_price) {
        this.month_price = month_price;
    }
    public float getHalfYPrice() {
        return halfy_price;
    }
    public void setHalfYPrice(float hy_price) {
        this.halfy_price = hy_price;
    }
    public float getYPrice() {
        return y_price;
    }
    public void setYPrice(float y_price) {
        this.y_price = y_price;
    }
    public float getPrice() {
        return price;
    }
    public void setPrice(float price) {
        this.price = price;
    }
    
    public float getMonthreturn() {
		return monthreturn;
	}
	public void setMonthreturn(float monthreturn) {
		this.monthreturn = monthreturn;
	}
	public float getHalfyreturn() {
		return halfyreturn;
	}
	public void setHalfyreturn(float halfyreturn) {
		this.halfyreturn = halfyreturn;
	}
	public float getYreturn() {
		return yreturn;
	}
	public void setYreturn(float yreturn) {
		this.yreturn = yreturn;
	}
	
	public float getWeight(){
		return weight;
	}
	public void setWeight(float weight){
		this.weight = weight;
	}
	public URL getChartURL() {
		return chartURL;
	}
	
	public URL formChartURL(String ticker) throws MalformedURLException{
		this.chartURL = new URL("http://chart.finance.yahoo.com/w?s="+ticker);
		return this.chartURL;
	}
	
	public void setChartURL(URL url){
		this.chartURL = url;
	}
}